-- MySQL dump 10.13  Distrib 5.5.52, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pfood_principal
-- ------------------------------------------------------
-- Server version	5.5.52-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `pfood_principal`
--


--
-- Table structure for table `auditorias`
--

DROP TABLE IF EXISTS `auditorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `modificadoem` datetime DEFAULT NULL,
  `acao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditorias`
--

LOCK TABLES `auditorias` WRITE;
/*!40000 ALTER TABLE `auditorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bebidas`
--

DROP TABLE IF EXISTS `bebidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bebidas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `valor` float NOT NULL,
  `descricao` text NOT NULL,
  `disponivel` varchar(45) DEFAULT NULL,
  `categorias_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bebidas_categorias1_idx` (`categorias_id`),
  CONSTRAINT `fk_bebidas_categorias1` FOREIGN KEY (`categorias_id`) REFERENCES `categorias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bebidas`
--

LOCK TABLES `bebidas` WRITE;
/*!40000 ALTER TABLE `bebidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `bebidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Hamburgers','Categoria onde estarão os condimentos para montar os hamburgers que serão vendidos no estabelecimento. Teste'),(2,'Pizzas','Condimentos para pizzas ');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumidores`
--

DROP TABLE IF EXISTS `consumidores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumidores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cpf` int(11) NOT NULL,
  `telefone` int(11) DEFAULT NULL,
  `nascimento` date DEFAULT NULL,
  `criacao` datetime NOT NULL,
  `alteracao` datetime NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `permissao` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Usuário do sitema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumidores`
--

LOCK TABLES `consumidores` WRITE;
/*!40000 ALTER TABLE `consumidores` DISABLE KEYS */;
INSERT INTO `consumidores` VALUES (1,'Teste','teste@teste.com.br',2147483647,NULL,NULL,'2016-11-01 13:57:00','2016-11-01 13:57:00','teste','$2a$08$Cf1f11ePArKlBJomM0F6a.ZbjhMDCEL68pJ97JHRsyeB3v080L6hO',1),(2,'Teste segundo usuario','teste@novo.com.br',2147483647,2147483647,NULL,'2016-11-11 12:33:00','2016-11-11 12:33:00','teste3','$2a$08$Cf1f11ePArKlBJomM0F6a.UFZ6Sp2bbz/FEWdXSFF6hx71tGrjUc.',1),(3,'Anderson Irias Hermogenes','anderson.irias@teste.com.br',2147483647,214748378,'2011-08-03','2016-11-11 14:46:17','2016-11-11 14:46:17','anderson','$2a$08$Cf1f11ePArKlBJomM0F6a.SuRisLP9HqNP1mm29XybNzbfeIHEeDO',1),(4,'JONATHAN PEREIRA RODRIGUES','guguhjpr@gmail.com',2147483647,2147483647,'2011-10-23','2016-11-12 19:05:26','2016-11-12 19:05:26','guguh23','$2a$08$Cf1f11ePArKlBJomM0F6a.p2udmMmPyuhmp/TKh9mmbU5K3BKxLu2',1),(5,'Lídia','lidiamaria365@gmail.com',2147483647,2147483647,'2011-04-13','2016-11-14 17:41:27','2016-11-14 17:41:27','lidia.maria','$2a$08$Cf1f11ePArKlBJomM0F6a.yIUEVvdMLlWvrlMDe9tmSe79Ilsj84u',1),(6,'jose','ewert_on@hotmail.com',2147483647,2147483647,'2011-10-16','2016-11-15 14:58:05','2016-11-15 14:58:05','jose3','$2a$08$Cf1f11ePArKlBJomM0F6a.UFZ6Sp2bbz/FEWdXSFF6hx71tGrjUc.',1),(7,'lt','lt@teste.com',2147483647,2147483647,'2019-04-02','2016-11-16 00:11:53','2016-11-16 00:11:53','oui','$2a$08$Cf1f11ePArKlBJomM0F6a.jMGfvX2PoWJSw4mjYdUKZYx4znFvVb2',1),(8,'JONATHAN PEREIRA RODRIGUES','jonathanjpr69@hotmail.com',2147483647,2147483647,'2011-10-23','2016-11-16 20:02:43','2016-11-16 20:02:43','jonathan','$2a$08$Cf1f11ePArKlBJomM0F6a.p2udmMmPyuhmp/TKh9mmbU5K3BKxLu2',1);
/*!40000 ALTER TABLE `consumidores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enderecos`
--

DROP TABLE IF EXISTS `enderecos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enderecos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cidade` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `rua` varchar(100) NOT NULL,
  `numero` varchar(100) NOT NULL,
  `complemento` varchar(100) NOT NULL,
  `consumidores_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_enderecos_consumidores_idx` (`consumidores_id`),
  CONSTRAINT `fk_enderecos_consumidores` FOREIGN KEY (`consumidores_id`) REFERENCES `consumidores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enderecos`
--

LOCK TABLES `enderecos` WRITE;
/*!40000 ALTER TABLE `enderecos` DISABLE KEYS */;
INSERT INTO `enderecos` VALUES (2,'Cidade negra','Novo','Rua das palmeiras','900','casa',3),(4,'Testolandia','Lar teste','AV teste','87','teste',1),(6,'gdg','dgdg','gg','dgd ','dgdfg',7),(7,'asjdaslkj','lkjsalkjas','sçlfaslç','1321321','sdasd',6);
/*!40000 ALTER TABLE `enderecos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estabelecimentos`
--

DROP TABLE IF EXISTS `estabelecimentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estabelecimentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `cnpj` varchar(100) NOT NULL,
  `ramo` varchar(100) DEFAULT NULL,
  `descricao` text,
  `rua` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `numero` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `site` varchar(100) NOT NULL,
  `telefone` varchar(45) NOT NULL,
  `criacao` datetime NOT NULL,
  `alteracao` datetime NOT NULL,
  `entrega` tinyint(1) NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `permissao` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='restaurantes que utilizarão o sitema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estabelecimentos`
--

LOCK TABLES `estabelecimentos` WRITE;
/*!40000 ALTER TABLE `estabelecimentos` DISABLE KEYS */;
INSERT INTO `estabelecimentos` VALUES (1,'Churrasquinho do zé ','Estabelecimento teste','121fd5afd6f6adfadfaad','','','teste','teste','teste',54,'estabelecimento@teste.com','teste.com','111111111111111','2016-11-01 17:34:00','2016-11-01 17:34:00',1,'estabelecimento','$2a$08$Cf1f11ePArKlBJomM0F6a.doi9KzmOLeThS0MTQyqmCCXt6P.E3.a',0),(2,'Estabelecimento teste','Estabelecimento teste 2','44444444444444444444','','','teste','teste','teste',45,'teste2@teste.com','teste2.com','9999999999','2016-11-03 16:03:00','2016-11-03 16:03:00',0,'teste2','$2a$08$Cf1f11ePArKlBJomM0F6a.UFZ6Sp2bbz/FEWdXSFF6hx71tGrjUc.',0);
/*!40000 ALTER TABLE `estabelecimentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filaentregas`
--

DROP TABLE IF EXISTS `filaentregas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filaentregas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chegada` datetime NOT NULL,
  `status` varchar(100) NOT NULL,
  `observacoes` varchar(255) DEFAULT NULL,
  `posicao` int(11) NOT NULL,
  `saida` datetime NOT NULL,
  `pedidos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_filaentregas_pedidos1_idx` (`pedidos_id`),
  CONSTRAINT `fk_filaentregas_pedidos1` FOREIGN KEY (`pedidos_id`) REFERENCES `pedidos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filaentregas`
--

LOCK TABLES `filaentregas` WRITE;
/*!40000 ALTER TABLE `filaentregas` DISABLE KEYS */;
/*!40000 ALTER TABLE `filaentregas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filapedidos`
--

DROP TABLE IF EXISTS `filapedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filapedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chegada` datetime NOT NULL,
  `status` varchar(100) NOT NULL,
  `observacoes` varchar(255) DEFAULT NULL,
  `posicao` int(11) NOT NULL,
  `saida` datetime NOT NULL,
  `pedidos_id` int(11) NOT NULL,
  `enderecos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_filapedidos_pedidos1_idx` (`pedidos_id`),
  CONSTRAINT `fk_filapedidos_pedidos1` FOREIGN KEY (`pedidos_id`) REFERENCES `pedidos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filapedidos`
--

LOCK TABLES `filapedidos` WRITE;
/*!40000 ALTER TABLE `filapedidos` DISABLE KEYS */;
INSERT INTO `filapedidos` VALUES (1,'2016-11-10 17:15:00','teste','bla bla bla',0,'2016-11-10 17:15:00',9,1),(2,'2016-11-10 17:23:00','Novo','',0,'2016-11-10 17:23:00',10,1),(3,'2016-11-10 19:18:31','Novo','',0,'2016-11-10 19:18:31',27,1),(4,'2016-11-10 19:21:39','Novo','',0,'2016-11-10 19:21:39',28,1),(5,'2016-11-10 19:22:35','Novo','',0,'2016-11-10 19:22:35',29,1),(6,'2016-11-10 19:24:42','Novo','',0,'2016-11-10 19:24:42',30,1),(7,'2016-11-11 11:39:40','Novo','',0,'2016-11-11 11:39:40',31,1),(8,'2016-11-11 12:35:11','Novo','',0,'2016-11-11 12:35:11',32,1),(9,'2016-11-11 13:53:31','Novo','',0,'2016-11-11 13:53:31',33,1),(10,'2016-11-11 16:15:24','Novo','',0,'2016-11-11 16:15:24',34,1),(11,'2016-11-11 17:44:05','Novo','',0,'2016-11-11 17:44:05',3,0),(12,'2016-11-11 18:01:51','Novo','',0,'2016-11-11 18:01:51',3,2),(13,'2016-11-11 18:21:50','Novo','',0,'2016-11-11 18:21:50',43,2),(14,'2016-11-11 19:26:37','Novo','',0,'2016-11-11 19:26:37',44,2),(15,'2016-11-11 19:59:35','Novo','',0,'2016-11-11 19:59:35',45,2),(16,'2016-11-14 17:44:03','Novo','',0,'2016-11-14 17:44:03',47,0),(17,'2016-11-14 21:20:35','Novo','',0,'2016-11-14 21:20:35',48,2),(18,'2016-11-15 15:02:21','Novo','',0,'2016-11-15 15:02:21',49,0),(19,'2016-11-16 11:22:43','Novo','',0,'2016-11-16 11:22:43',50,0),(20,'2016-11-16 15:43:57','Novo','',0,'2016-11-16 15:43:57',51,0),(21,'2016-11-16 16:04:32','Novo','',0,'2016-11-16 16:04:32',52,0),(22,'2016-11-16 16:04:51','Novo','',0,'2016-11-16 16:04:51',53,0),(23,'2016-11-16 16:07:12','Novo','',0,'2016-11-16 16:07:12',55,6),(24,'2016-11-16 18:54:52','Novo','',0,'2016-11-16 18:54:52',56,2),(25,'2016-11-16 20:01:39','Novo','',0,'2016-11-16 20:01:39',57,0),(26,'2016-11-16 20:04:09','Novo','',0,'2016-11-16 20:04:09',58,0),(27,'2016-11-17 13:31:59','Novo','',0,'2016-11-17 13:31:59',59,0),(28,'2016-11-17 13:45:01','Novo','',0,'2016-11-17 13:45:01',60,6),(29,'2016-11-17 13:47:31','Novo','',0,'2016-11-17 13:47:31',61,7),(30,'2016-11-17 17:51:06','Novo','',0,'2016-11-17 17:51:06',62,0),(31,'2016-11-17 21:33:52','Novo','',0,'2016-11-17 21:33:52',63,2),(32,'2016-11-18 17:52:50','Novo','',0,'2016-11-18 17:52:50',64,0),(33,'2016-11-18 18:23:35','Novo','',0,'2016-11-18 18:23:35',65,2),(34,'2016-11-18 18:35:58','Novo','',0,'2016-11-18 18:35:58',66,2);
/*!40000 ALTER TABLE `filapedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredientes`
--

DROP TABLE IF EXISTS `ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `estoque` int(11) NOT NULL,
  `criacao` datetime NOT NULL,
  `adicional` tinyint(1) NOT NULL,
  `valor` float NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `categorias_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ingredientes_categorias1` (`categorias_id`),
  CONSTRAINT `fk_ingredientes_categorias1` FOREIGN KEY (`categorias_id`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredientes`
--

LOCK TABLES `ingredientes` WRITE;
/*!40000 ALTER TABLE `ingredientes` DISABLE KEYS */;
INSERT INTO `ingredientes` VALUES (5,'Carne hamburguer','Carne de boi hamburguer',45,'2016-11-06 15:34:00',1,7,'carne.jpg',1),(6,'Alface','Folha de alface normal ',10,'2016-11-06 15:49:00',1,3,'alface.jpg',1),(7,'Pão integral','Pão de hamburguer integral',10,'2016-11-06 15:52:00',1,2,'pao.jpg',1),(8,'Queijo Mussarela','Queijo mussarela',10,'2016-11-06 15:54:00',1,1,'queijo.jpg',1),(9,'Tomate','Rodela de tomate',10,'2016-11-06 15:55:00',1,1,'tomate.jpg',1),(10,'Bacon ','Bacon em tira',10,'2016-11-06 16:02:00',1,2,'bacon.jpg',1),(11,'Tomate','Tomate meio assado ',10,'2016-11-08 16:18:00',0,2,'',2),(12,'Muçarela','Queijo muçarela para pizza',10,'2016-11-08 16:19:00',1,3,'',2),(13,'Carne moida','Carne de boi moida',10,'2016-11-08 16:20:00',1,5,'',2),(14,'Bacon','Bacon em cubos',10,'2016-11-08 16:21:00',0,5,'',2),(15,'Calabresa','Calabresa',10,'2016-11-08 16:21:00',0,5,'',2),(16,'Frango','Peito de frango desfiado',10,'2016-11-08 16:22:00',0,5,'',2),(17,'Peperone','Teste peperone',10,'2016-11-14 17:50:56',0,7,NULL,2),(18,'Pão Australiano','Pão da australia',10,'2016-11-18 17:40:54',0,3,NULL,1);
/*!40000 ALTER TABLE `ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesas`
--

DROP TABLE IF EXISTS `mesas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mesas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quant_pessoas` int(11) NOT NULL,
  `estabelecimentos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mesas_estabelecimentos1_idx` (`estabelecimentos_id`),
  CONSTRAINT `fk_mesas_estabelecimentos1` FOREIGN KEY (`estabelecimentos_id`) REFERENCES `estabelecimentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesas`
--

LOCK TABLES `mesas` WRITE;
/*!40000 ALTER TABLE `mesas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mesas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` float NOT NULL,
  `entrega` tinyint(1) NOT NULL,
  `form_pagamento` varchar(100) NOT NULL,
  `criacao` datetime NOT NULL,
  `observacoes` varchar(255) DEFAULT NULL,
  `alteracao` datetime NOT NULL,
  `consumidores_id` int(11) NOT NULL,
  `ingredientes` text,
  `pratos` text,
  PRIMARY KEY (`id`),
  KEY `fk_pedidos_consumidores1_idx` (`consumidores_id`),
  CONSTRAINT `fk_pedidos_consumidores1` FOREIGN KEY (`consumidores_id`) REFERENCES `consumidores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,43,1,'1','2016-11-10 15:24:49',NULL,'2016-11-10 15:24:49',1,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 6 Alface 30 Folha de alface normal ; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 8 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 10 Bacon  2 Bacon em tira; ',''),(2,7,0,'0','2016-11-10 15:25:11',NULL,'2016-11-10 15:25:11',1,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; '),(3,20,1,'0','2016-11-10 15:26:59',NULL,'2016-11-10 15:26:59',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(4,15,1,'0','2016-11-10 15:41:49',NULL,'2016-11-10 15:41:49',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(5,20,0,'0','2016-11-10 15:43:20',NULL,'2016-11-10 15:43:20',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(6,7,1,'1','2016-11-10 16:00:47',NULL,'2016-11-10 16:00:47',1,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; '),(7,15,0,'2','2016-11-10 16:01:31',NULL,'2016-11-10 16:01:31',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(8,15,1,'0','2016-11-10 16:03:02',NULL,'2016-11-10 16:03:02',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(9,20,0,'0','2016-11-10 17:07:03',NULL,'2016-11-10 17:07:03',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(10,15,0,'1','2016-11-10 17:16:02',NULL,'2016-11-10 17:16:02',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(11,15,0,'1','2016-11-10 17:30:11',NULL,'2016-11-10 17:30:11',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(12,27,0,'2','2016-11-10 17:31:06',NULL,'2016-11-10 17:31:06',1,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(13,27,0,'2','2016-11-10 17:31:49',NULL,'2016-11-10 17:31:49',1,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(14,20,0,'0','2016-11-10 17:33:36',NULL,'2016-11-10 17:33:36',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(15,20,0,'0','2016-11-10 17:34:01',NULL,'2016-11-10 17:34:01',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(16,20,0,'0','2016-11-10 17:34:38',NULL,'2016-11-10 17:34:38',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(17,20,0,'0','2016-11-10 17:35:16',NULL,'2016-11-10 17:35:16',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(18,20,1,'0','2016-11-10 18:06:05',NULL,'2016-11-10 18:06:05',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(19,20,1,'0','2016-11-10 18:08:00',NULL,'2016-11-10 18:08:00',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(20,15,0,'2','2016-11-10 18:11:16',NULL,'2016-11-10 18:11:16',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(21,7,0,'2','2016-11-10 18:22:22',NULL,'2016-11-10 18:22:22',1,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; ',''),(22,20,0,'0','2016-11-10 18:34:49',NULL,'2016-11-10 18:34:49',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(23,20,0,'2','2016-11-10 18:35:48',NULL,'2016-11-10 18:35:48',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(24,15,0,'1','2016-11-10 18:45:26',NULL,'2016-11-10 18:45:26',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(25,15,0,'0','2016-11-10 18:52:22',NULL,'2016-11-10 18:52:22',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(26,20,0,'0','2016-11-10 19:11:55',NULL,'2016-11-10 19:11:55',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(27,15,0,'0','2016-11-10 19:18:31',NULL,'2016-11-10 19:18:31',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(28,20,0,'0','2016-11-10 19:21:39',NULL,'2016-11-10 19:21:39',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(29,15,0,'0','2016-11-10 19:22:35',NULL,'2016-11-10 19:22:35',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(30,15,0,'0','2016-11-10 19:24:42',NULL,'2016-11-10 19:24:42',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(31,20,0,'0','2016-11-11 11:39:40',NULL,'2016-11-11 11:39:40',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(32,20,0,'0','2016-11-11 12:35:11',NULL,'2016-11-11 12:35:11',2,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(33,20,0,'0','2016-11-11 13:53:31',NULL,'2016-11-11 13:53:31',1,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(34,15,0,'1','2016-11-11 16:15:24',NULL,'2016-11-11 16:15:24',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(35,20,0,'1','2016-11-11 16:32:09',NULL,'2016-11-11 16:32:09',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(36,15,0,'1','2016-11-11 16:32:43',NULL,'2016-11-11 16:32:43',1,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; Id do prato: 3 Hamburger boi 20 Hamburger boi ; Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(37,43,0,'0','2016-11-11 17:43:57',NULL,'2016-11-11 17:43:57',3,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 6 Alface 30 Folha de alface normal ; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 8 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 10 Bacon  2 Bacon em tira; ',''),(38,15,0,'0','2016-11-11 18:01:24',NULL,'2016-11-11 18:01:24',3,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(39,15,0,'0','2016-11-11 18:09:35',NULL,'2016-11-11 18:09:35',3,'','Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(40,7,0,'1','2016-11-11 18:17:09',NULL,'2016-11-11 18:17:09',3,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; '),(41,20,0,'0','2016-11-11 18:19:02',NULL,'2016-11-11 18:19:02',3,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(42,7,0,'0','2016-11-11 18:20:12',NULL,'2016-11-11 18:20:12',3,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; '),(43,7,0,'0','2016-11-11 18:21:45',NULL,'2016-11-11 18:21:45',3,'','Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; '),(44,20,0,'0','2016-11-11 19:26:33',NULL,'2016-11-11 19:26:33',3,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(45,20,0,'1','2016-11-11 19:59:16',NULL,'2016-11-11 19:59:16',3,'','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(46,45,0,'0','2016-11-12 19:07:35',NULL,'2016-11-12 19:07:35',4,'Id do ingrediente: 11 Tomate 2 Tomate meio assado ; Id do ingrediente: 12 Muçarela 3 Queijo muçarela para pizza; Id do ingrediente: 13 Carne moida 5 Carne de boi moida; Id do ingrediente: 14 Bacon 5 Bacon em cubos; Id do ingrediente: 15 Calabresa 5 Calabresa; Id do ingrediente: 16 Frango 5 Peito de frango desfiado; ','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(47,72,0,'1','2016-11-14 17:43:31',NULL,'2016-11-14 17:43:31',5,'Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 6 Alface 30 Folha de alface normal ; ','Id do prato: 6 Alface 30 Folha de alface normal ; '),(48,39,0,'1','2016-11-14 21:20:24',NULL,'2016-11-14 21:20:24',3,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 6 Alface 3 Folha de alface normal ; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 8 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 10 Bacon  2 Bacon em tira; ','Id do prato: 6 Alface 3 Folha de alface normal ; Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(49,15,0,'1','2016-11-15 15:02:13',NULL,'2016-11-15 15:02:13',6,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 6 Alface 3 Folha de alface normal ; ',''),(50,14,0,'0','2016-11-16 11:22:37',NULL,'2016-11-16 11:22:37',6,'Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 6 Alface 3 Folha de alface normal ; Id do ingrediente: 10 Bacon  2 Bacon em tira; ',''),(51,30,0,'0','2016-11-16 15:43:45',NULL,'2016-11-16 15:43:45',7,'Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 8 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 10 Bacon  2 Bacon em tira; ','Id do prato: 3 Hamburger boi 20 Hamburger boi ; '),(52,88,0,'0','2016-11-16 16:04:18',NULL,'2016-11-16 16:04:18',7,'Id do ingrediente: 6 Alface 3 Folha de alface normal ; Id do ingrediente: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 8 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 9 Tomate 1 Rodela de tomate; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 10 Bacon  2 Bacon em tira; Id do ingrediente: 7 Pão integral 2 Pão de hamburguer integral; ','Id do prato: 3 Hamburger boi 20 Hamburger boi ; Id do prato: 3 Hamburger boi 20 Hamburger boi ; Id do prato: 5 Carne hamburguer 7 Carne de boi hamburguer; Id do prato: 4 Hamburger queijo 15 Hamburger com queijo; '),(53,3,0,'0','2016-11-16 16:04:49',NULL,'2016-11-16 16:04:49',7,'Id do ingrediente: 6 Alface 3 Folha de alface normal ; ',''),(54,6,0,'0','2016-11-16 16:07:06',NULL,'2016-11-16 16:07:06',7,'','Id do prato: 6 Alface 3 Folha de alface normal ; Id do prato: 6 Alface 3 Folha de alface normal ; '),(55,6,0,'0','2016-11-16 16:07:07',NULL,'2016-11-16 16:07:07',7,'','Id do prato: 6 Alface 3 Folha de alface normal ; Id do prato: 6 Alface 3 Folha de alface normal ; '),(56,130,0,'0','2016-11-16 18:54:48',NULL,'2016-11-16 18:54:48',3,'','Id do prato: 113 Hamburger boi 20 Hamburger boi ; Id do prato: 114 Hamburger queijo 15 Hamburger com queijo; Id do prato: 115 Sanduiche de Presunto 15 Sanduiche de Presunto; Id do prato: 116 Pizza de Calabresa 40 Pizza grande de calabresa; Id do prato: 116 Pizza de Calabresa 40 Pizza grande de calabresa; '),(57,40,0,'0','2016-11-16 20:01:35',NULL,'2016-11-16 20:01:35',3,'','Id do prato: 116 Pizza de Calabresa 40 Pizza grande de calabresa; '),(58,13,0,'1','2016-11-16 20:03:49',NULL,'2016-11-16 20:03:49',8,'Id do ingrediente: 105 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 107 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 108 Queijo Mussarela 1 Queijo mussarela; Id do ingrediente: 109 Tomate 1 Rodela de tomate; Id do ingrediente: 1010 Bacon  2 Bacon em tira; ',''),(59,10,0,'2','2016-11-17 13:31:48',NULL,'2016-11-17 13:31:48',6,'Id do ingrediente: 105 Carne hamburguer 7 Carne de boi hamburguer; Id do ingrediente: 107 Pão integral 2 Pão de hamburguer integral; Id do ingrediente: 108 Queijo Mussarela 1 Queijo mussarela; ',''),(60,15,0,'0','2016-11-17 13:44:26',NULL,'2016-11-17 13:44:26',7,'Id do ingrediente: 1011 Tomate 2 Tomate meio assado ; Id do ingrediente: 1012 Muçarela 3 Queijo muçarela para pizza; Id do ingrediente: 1014 Bacon 5 Bacon em cubos; Id do ingrediente: 1015 Calabresa 5 Calabresa; ',''),(61,35,0,'0','2016-11-17 13:47:23',NULL,'2016-11-17 13:47:23',6,'','Id do prato: 113 Hamburger boi 20 Hamburger boi ; Id do prato: 115 Sanduiche de Presunto 15 Sanduiche de Presunto; '),(62,70,0,'0','2016-11-17 17:51:00',NULL,'2016-11-17 17:51:00',3,'','Id do prato: 114 Hamburger queijo 15 Hamburger com queijo; Id do prato: 115 Sanduiche de Presunto 15 Sanduiche de Presunto; Id do prato: 116 Pizza de Calabresa 40 Pizza grande de calabresa; '),(63,3,0,'2','2016-11-17 21:33:49',NULL,'2016-11-17 21:33:49',3,'Id do ingrediente: 1012 Muçarela 3 Queijo muçarela para pizza; ',''),(64,16,0,'0','2016-11-18 17:52:44',NULL,'2016-11-18 17:52:44',3,'<td>Carne hamburguer</td><td id=\'valor105\'>7</td><td>Carne de boi hamburguer</td>,<td>Alface</td><td id=\'valor106\'>3</td><td>Folha de alface normal </td>,<td>Queijo Mussarela</td><td id=\'valor108\'>1</td><td>Queijo mussarela</td>,<td>Tomate</td><td id=\'valor109\'>1</td><td>Rodela de tomate</td>,<td>Bacon </td><td id=\'valor1010\'>2</td><td>Bacon em tira</td>,<td>Pão integral</td><td id=\'valor107\'>2</td><td>Pão de hamburguer integral</td>',''),(65,60,0,'2','2016-11-18 18:23:32',NULL,'2016-11-18 18:23:32',3,'','<td>Hamburger boi</td><td id=\'valor113\'>20</td><td>Hamburger boi </td>,<td>Pizza de Calabresa</td><td id=\'valor116\'>40</td><td>Pizza grande de calabresa</td>'),(66,162,0,'0','2016-11-18 18:35:55',NULL,'2016-11-18 18:35:55',3,'<td>Carne hamburguer</td><td id=\'valor105\'>7</td><td>Carne de boi hamburguer</td>,<td>Alface</td><td id=\'valor106\'>3</td><td>Folha de alface normal </td>,<td>Pão integral</td><td id=\'valor107\'>2</td><td>Pão de hamburguer integral</td>,<td>Queijo Mussarela</td><td id=\'valor108\'>1</td><td>Queijo mussarela</td>,<td>Tomate</td><td id=\'valor109\'>1</td><td>Rodela de tomate</td>,<td>Bacon </td><td id=\'valor1010\'>2</td><td>Bacon em tira</td>','<td>Pizza de Calabresa</td><td id=\'valor116\'>40</td><td>Pizza grande de calabresa</td>,<td>Hamburger boi</td><td id=\'valor113\'>20</td><td>Hamburger boi </td>,<td>Hamburger queijo</td><td id=\'valor114\'>15</td><td>Hamburger com queijo</td>');
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_has_pratos`
--

DROP TABLE IF EXISTS `pedidos_has_pratos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos_has_pratos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedidos_id` int(11) NOT NULL,
  `pratos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pedidos_has_pratos_pedidos1_idx` (`pedidos_id`),
  KEY `fk_pedidos_has_pratos_pratos1_idx` (`pratos_id`),
  CONSTRAINT `fk_pedidos_has_pratos_pedidos1` FOREIGN KEY (`pedidos_id`) REFERENCES `pedidos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pedidos_has_pratos_pratos1` FOREIGN KEY (`pratos_id`) REFERENCES `pratos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_has_pratos`
--

LOCK TABLES `pedidos_has_pratos` WRITE;
/*!40000 ALTER TABLE `pedidos_has_pratos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos_has_pratos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pratos`
--

DROP TABLE IF EXISTS `pratos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pratos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` float NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `ativo` tinyint(1) NOT NULL,
  `criacao` datetime NOT NULL,
  `alteracao` datetime NOT NULL,
  `montagem` varchar(45) NOT NULL,
  `categorias_id` int(11) NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pratos_categorias1_idx` (`categorias_id`),
  CONSTRAINT `fk_pratos_categorias1` FOREIGN KEY (`categorias_id`) REFERENCES `categorias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pratos`
--

LOCK TABLES `pratos` WRITE;
/*!40000 ALTER TABLE `pratos` DISABLE KEYS */;
INSERT INTO `pratos` VALUES (3,20,'Hamburger boi','Hamburger boi ',1,'2016-11-06 16:16:00','2016-11-06 16:16:00','Teste',1,'hamburger1.jpg'),(4,15,'Hamburger queijo','Hamburger com queijo',1,'2016-11-06 16:33:00','2016-11-06 16:33:00','Teste',1,'hamburger2.jpg'),(5,15,'Sanduiche de Presunto','Sanduiche de Presunto',1,'2016-11-06 16:36:00','2016-11-06 16:36:00','Teste',1,'sanduiche.jpg'),(6,40,'Pizza de Calabresa','Pizza grande de calabresa',1,'2016-11-14 12:34:03','2016-11-14 12:34:03','teste',2,'pizza-RC-Fones.jpg');
/*!40000 ALTER TABLE `pratos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pratos_has_ingredientes`
--

DROP TABLE IF EXISTS `pratos_has_ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pratos_has_ingredientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pratos_id` int(11) NOT NULL,
  `ingredientes_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pratos_has_ingredientes_pratos1_idx` (`pratos_id`),
  KEY `fk_pratos_has_ingredientes_ingredientes1_idx` (`ingredientes_id`),
  CONSTRAINT `fk_pratos_has_ingredientes_ingredientes1` FOREIGN KEY (`ingredientes_id`) REFERENCES `ingredientes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pratos_has_ingredientes_pratos1` FOREIGN KEY (`pratos_id`) REFERENCES `pratos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pratos_has_ingredientes`
--

LOCK TABLES `pratos_has_ingredientes` WRITE;
/*!40000 ALTER TABLE `pratos_has_ingredientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pratos_has_ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criacao` datetime NOT NULL,
  `alteracao` datetime NOT NULL,
  `login` varchar(100) NOT NULL,
  `tipo` varchar(45) NOT NULL,
  `permissao` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-18 16:48:03

